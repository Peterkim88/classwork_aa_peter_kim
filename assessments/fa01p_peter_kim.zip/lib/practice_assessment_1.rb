require "byebug"

def first_letter_vowel_count(sentence)

    words = sentence.split(" ")
    i = 0
    words.each { |word| i += 1 if "aeiou".include?(word[0].downcase) }
    return i

end

def count_true(array, prc)
    i = 0
    array.each { |el| i += 1 if prc.call(el) }
    return i
end

def procformation(array, prc1, prc2, prc3)
    new_arr = []
    array.each do |el|
        if prc1.call(el)
            new_arr << prc2.call(el)
        else
            new_arr << prc3.call(el)
        end
    end
    new_arr
end

def array_of_array_sum(array)
    array.flatten.sum
end

def selective_reverse(sentence)
    words = sentence.split(" ")
    new_words = []
    words.each do |word|
        if "aeiou".include?(word[0].downcase) || "aeiou".include?(word[-1].downcase)
            new_words << word
        else
            new_words << word.reverse
        end
    end
    new_words.join(" ")
end

def hash_missing_keys(hash, *args)
    non_inclusive_args = []
    args.each { |arg| non_inclusive_args << arg if !hash.include?(arg) }
    non_inclusive_args
end