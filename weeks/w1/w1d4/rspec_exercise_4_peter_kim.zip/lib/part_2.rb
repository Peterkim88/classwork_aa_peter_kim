def proper_factors(num)
    factors = []
    (1...num).each { |n| factors << n if num % n == 0 }
    factors
end

def aliquot_sum(num)
    proper_factors(num).sum
end

def perfect_number?(num)
    aliquot_sum(num) == num
end

def ideal_numbers(num)
    ideal_nums = []
    counter = 0
    i = 1
    while counter < num
        if perfect_number?(i)
            ideal_nums << i
            counter += 1
        end
        i += 1
    end
    ideal_nums
end
    